#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <windows.h>

#define MAX_ITEMS 1024
#define EXPLORER_COMMAND_SIZE 2048

char* itemList[MAX_ITEMS];
int itemCount = 0;

/* 確保したメモリを解放する */
void freeItemList(void)
{
    int i;

    for (i = 0; i < itemCount; i++) {
        free(itemList[i]);
        itemList[i] = NULL;
    }

    itemCount = 0;
}

/* snprintf の結果をチェックする */
int isSnprintfFailed(int result, size_t bufferSize)
{
    return (result < 0 || (size_t)result >= bufferSize);
}

/* 指定フォルダ内のファイル＋フォルダを1階層だけ取得する */
void scanFolder(const char* folderPath)
{
    WIN32_FIND_DATAA findData;
    HANDLE hFind;

    char searchPath[MAX_PATH];
    char fullPath[MAX_PATH];
    int written;

    itemCount = 0;

    /* 検索用パスを作る 例: C:\test\* */
    written = snprintf(searchPath, sizeof(searchPath), "%s\\*", folderPath);
    if (isSnprintfFailed(written, sizeof(searchPath))) {
        printf("Search path is too long.\n");
        return;
    }

    hFind = FindFirstFileA(searchPath, &findData);

    if (hFind == INVALID_HANDLE_VALUE) {
        printf("Could not open folder.\n");
        return;
    }

    do {
        char* copiedPath;

        /* "." と ".." は除外 */
        if (strcmp(findData.cFileName, ".") == 0 ||
            strcmp(findData.cFileName, "..") == 0) {
            continue;
        }

        if (itemCount >= MAX_ITEMS) {
            printf("Item limit reached. Some items were not scanned.\n");
            break;
        }

        /* フルパス作成 */
        written = snprintf(fullPath, sizeof(fullPath), "%s\\%s", folderPath, findData.cFileName);
        if (isSnprintfFailed(written, sizeof(fullPath))) {
            printf("Skipped an item because its full path is too long.\n");
            continue;
        }

        /* 文字列をコピーして配列に保存 */
        copiedPath = _strdup(fullPath);
        if (copiedPath == NULL) {
            printf("Memory allocation failed.\n");
            break;
        }

        itemList[itemCount] = copiedPath;
        itemCount++;

    } while (FindNextFileA(hFind, &findData));

    FindClose(hFind);
}

/* Explorerで対象を選択状態にする */
int selectInExplorer(const char* path)
{
    char command[EXPLORER_COMMAND_SIZE];
    int written;
    HINSTANCE result;

    written = snprintf(command, sizeof(command), "/select,\"%s\"", path);
    if (isSnprintfFailed(written, sizeof(command))) {
        printf("Explorer command is too long.\n");
        return 0;
    }

    result = ShellExecuteA(
        NULL,
        "open",
        "explorer.exe",
        command,
        NULL,
        SW_SHOWNORMAL
    );

    if ((INT_PTR)result <= 32) {
        printf("Failed to launch Explorer. Error code: %ld\n", (long)(INT_PTR)result);
        return 0;
    }

    return 1;
}

int main(int argc, char* argv[])
{
    int r;
    char* folderPath;

    srand((unsigned int)time(NULL));

    /* 右クリックフォルダのパスが渡されているかチェック */
    if (argc < 2) {
        printf("Folder path was not specified.\n");
        return 1;
    }

    folderPath = argv[1];

    scanFolder(folderPath);

    if (itemCount == 0) {
        printf("No target item was found.\n");
        freeItemList();
        return 1;
    }

    r = rand() % itemCount;

    printf("Selected item: %s\n", itemList[r]);

    selectInExplorer(itemList[r]);

    freeItemList();

    return 0;
}
